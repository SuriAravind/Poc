/*
 * Copyright 2018 ABSA Group Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package za.co.absa.cobrix.cobol.parser.parse

import org.scalatest.FunSuite
import za.co.absa.cobrix.cobol.parser.CopybookParser
import za.co.absa.cobrix.cobol.parser.exceptions.SyntaxErrorException

class ParserFieldsSpec extends FunSuite {

  test("Test parser field names") {
    val fields: List[String] = List(
      "FIELD",
      "X",
      "X9",
      "A",
      "A9",
      "V",
      "V9",
      "S",
      "S9",
      "S99VPP999",
      "SVPP999",
      "SV",
      "SP99",
      "S99PP",
      "Z99PP",
      "ZZ",
      "ZZPP",
      "ZZ99",
      "ZZV",
      "ZZPPV",
      "ZZ99V",
      "ZZV9",
      "ZZPPV9",
      "ZZ99V9"
    )

    for (elem <- fields) {
      val copybook: String =
        s"""********************************************
           |        01  RECORD.
           |           02  ${elem}           PIC X.
           |********************************************
           |""".stripMargin

      CopybookParser.parseTree(copybook)
    }
  }
}
