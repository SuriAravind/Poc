/**
 * 
 */
/**
 * @author Bruce01
 *
 */
package net.sf.JRecord.cbl2xml.zTest.xml2cbl.occursDepending.common;