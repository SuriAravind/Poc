package net.sf.JRecord.cbl2xml.zTest.xml2cbl.occursDepending.common;


public abstract class PCblBase implements IProcessCobolTree {

	public PCblBase() {
	}

	@Override
	public void intField(String name, int value, ArrayIndex indexs) {

	}

	@Override
	public void startGroup(String name, ArrayIndex indexs) {

	}

	@Override
	public void endGroup(String name) {
	}

	@Override
	public void startArray(String name, ArrayIndex indexs) {

	}

	@Override
	public void endArray(String name) {

	}
}
