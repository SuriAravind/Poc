package net.sf.cb2xml.def;


/**
 * For internal use in cb2xml / JRecord do not use this interface.
 * It will change in the future !!!
 * 
 * @author Bruce Martin
 *
 * 
 */
public interface IBasicDialect {

	public abstract NumericDefinition getNumericDefinition();
	
}
