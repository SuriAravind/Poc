package net.sf.cb2xml.analysis;

public interface IAddItem {

	public void addItem(Item item);
	public void addCondition(Condition condition);
	public void addComment(String comment);

	
}
