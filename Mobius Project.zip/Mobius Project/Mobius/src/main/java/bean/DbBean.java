package bean;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by Suriyanarayanan K
 * on 24/03/21 5:49 PM.
 */
@Builder
@Setter
@Getter
@ToString
public class DbBean {
    /**
     * Line 1
     *
     */
    private Date reportDate;
    private String reportId;
    private String versionNo;
    private Long pages;
    private String status;
    private String datasetName;
    private String micrSubscript;
    private String dataType;
    /**
     * Line 2
     */
    private String comment;
    private String recallExpDate;
    private String recordStatusDate;

    /**
     *
     * Line 3
     */
    private String unit;
    private String volumnSer;
    private String expirationDate;
    private String seqNo;
    private String migrationDatasetName;
    private String numberOfBytes;
    private String shareFlag;

}
