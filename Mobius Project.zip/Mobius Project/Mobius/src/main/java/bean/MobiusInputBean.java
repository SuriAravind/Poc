package bean;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 11:39 AM.
 */
@Getter
@Setter
@Builder
public class MobiusInputBean {
    private String host;
    private String user;
    private String password;
    private String remoteFileName;
    private String remoteTargetDirectory;
    private String rollNo;
    private String className;
    private String msgClassName;
    private String diskPrefix;
    private String vsamDatasetPrefix;
    private String leRuntimeDataset;
    private String finalFileName;
    private String unit;
    private String space;
    private String userID;
    private Boolean isReportVersionOnly;
    private String archivalValues;
    private String saveLocation;
    private OutputType outputType;
    private Boolean isRetrievalDblist;
    private Boolean isArchivalReport;

    private Boolean isDbListReportFileCreator;
    private String localDbListFilePath;
}
