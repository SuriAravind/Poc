package bean;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Created by Suriyanarayanan K
 * on 18/03/21 4:36 PM.
 */
@Builder
@Getter
@Setter
public class AttachmentInfo {
    private String attachmentId;
    private String attachmentPath;
    private String fullPath;
    private String attachmentDate;
}
