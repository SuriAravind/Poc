package bean;

import lombok.*;

/**
 * Created by Suriyanarayanan K
 * on 07/04/21 4:35 PM.
 */
@Data
@Builder
@NoArgsConstructor(access=AccessLevel.PUBLIC)
@AllArgsConstructor(access=AccessLevel.PUBLIC)
public class MobiusReportVersionBean {

    private String reportName;
    private Long startLineNumber;
    private Long endLineNumber;
    private Boolean isCsvFileApproach;
    private Boolean isTestModel;
    private String reportCSVFilePath;
    private String dbListFilePath;

    /**
     * Pre-analysis
     */
    private String schemaId;


    /**
     * Extraction Details
     */
    private String reportId;
    private String reportAliasName;
    private Long reportFromDate;
    private Long reportToDate;
    private Long versionCount;

}
