package bean;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 11:57 AM.
 */
public enum OutputType {
    XML,SIP,CSV;
}
