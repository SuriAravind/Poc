package bean;

import lombok.Builder;
import lombok.Getter;

/**
 * Created by Suriyanarayanan K
 * on 22/03/21 12:54 PM.
 */
@Builder
@Getter
public class ReportVersionBean {
    private String reportId;
    private String versionNo;
    private String sessionId;
}
