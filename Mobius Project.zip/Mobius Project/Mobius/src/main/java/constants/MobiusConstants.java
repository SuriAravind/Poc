package constants;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 12:10 PM.
 */
public class MobiusConstants {
    public static String LOGFILE="LogInfo.log";
    public static String TAG="===";
    public static String EMPTY_SPACE=" ";
    public static String NL="\n";
}
