package processor;

import bean.DbBean;
import bean.MobiusInputBean;
import org.apache.commons.net.ftp.FTPClient;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static constants.MobiusConstants.TAG;
import static utils.UtilityHelper.readFilesAsString;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 11:28 AM.
 */
public class DbListProcessor extends SharedProcessor {
    public static String REPORT="-REPORT";
    private FTPClient ftpClient;

    public DbListProcessor(MobiusInputBean mobiusInputBean , FTPClient ftpClient) {
        super(mobiusInputBean);
        this.ftpClient=ftpClient;
    }
    public DbListProcessor() {
        super(null);
    }

    /**
     * Start Retrival DBList into Local
     *
     * @return
     * @throws Exception
     */
    public String retrieveDBListFromMainFrameDBIntoLocal() throws Exception {
        String dblistJobFile=createDBListJobFile();
        uploadFile(dblistJobFile , ftpClient , "dbList job");
        String jobLogFolderName=fetchJobLogFolderName();
        String logFileFromMainFrameFilePath=retrieveJobLogFolder(ftpClient , jobLogFolderName);
        System.out.println("Successfully retrieved folder " + jobLogFolderName);
        boolean jobStatus=fetchJobStatus(logFileFromMainFrameFilePath);
        System.out.println("Job Status " + jobStatus);
        String dbFinalOutputFilePath=null;
        if (jobStatus) {
            dbFinalOutputFilePath=retrieveFinalOutputFile(mobiusInputBean.getFinalFileName() , mobiusInputBean.getSaveLocation() , ftpClient);
            dbFinalOutputFilePath=retrieveFinalOutputFile(mobiusInputBean.getFinalFileName() , mobiusInputBean.getSaveLocation() , ftpClient);
            System.out.println(" Final DBList Output File archived at " + dbFinalOutputFilePath);
        } else {
            System.err.println("Delete Job Status | DBList Job Failed");
        }
        return dbFinalOutputFilePath;
    }

    /**
     * Create DB List Job File
     *
     * @return
     * @throws Exception
     */
    private String createDBListJobFile() throws Exception {
        StringBuffer dbJobFileStringBuffer=new StringBuffer();
        dbJobFileStringBuffer.append(readFilesAsString("/template/DBListMobius.txt")
                                             .replace(TAG + "USER" + TAG , mobiusInputBean.getUser())
                                             .replace(TAG + "ROLL_NO" + TAG , mobiusInputBean.getRollNo())
                                             .replace(TAG + "CLASS" + TAG , mobiusInputBean.getClassName())
                                             .replace(TAG + "MSGCLASS" + TAG , mobiusInputBean.getMsgClassName())
                                             .replace(TAG + "DISK_PREFIX" + TAG , mobiusInputBean.getDiskPrefix())
                                             .replace(TAG + "VSAM_DATASET_PREFIX" + TAG , mobiusInputBean.getVsamDatasetPrefix())
                                             .replace(TAG + "LE_RUNTIME_DATASET" + TAG , mobiusInputBean.getLeRuntimeDataset())
                                             .replace(TAG + "FINAL_FILE_NAME" + TAG , mobiusInputBean.getFinalFileName())
                                             .replace(TAG + "UNIT" + TAG , mobiusInputBean.getUnit())
                                             .replace(TAG + "SPACE" + TAG , mobiusInputBean.getSpace()));
        File jobLocalFile=new File(mobiusInputBean.getSaveLocation() + File.separator + "DBJobFile.txt");
        if (!jobLocalFile.exists()) {
            jobLocalFile.createNewFile();
        }
        PrintWriter printWriter=new PrintWriter(jobLocalFile.getAbsolutePath());
        printWriter.append(dbJobFileStringBuffer.toString());
        printWriter.flush();
        printWriter.close();
        String localFilePath=jobLocalFile.getAbsolutePath();
        return localFilePath;
    }

    /**
     * Retrieve All DbList Bean
     *
     * @param outputDbListPath
     * @return
     */
    public List<DbBean> retrieveAllDBList(String outputDbListPath , boolean isCreateFile) {
        PrintWriter printWriter=null;
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd");
        if (isCreateFile) {
            try {
                printWriter=new PrintWriter(new File(outputDbListPath).getParent() + File.separator + "ReportInputFile.csv");
                printWriter.append("Sno,ReportDate,ReportId,VersionNo"+"\n");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        List<DbBean> dbBeanList=new ArrayList<>();
        File file=new File(outputDbListPath);
        System.out.println(file.getAbsolutePath());
        long recordCount=0;
        try (BufferedReader dbBufferReader=new BufferedReader(new FileReader(file) , 4096)) {
            String currentLine="";
            List<String> reportVersionLine=null;
            int count=0;
            if (dbBufferReader.ready()) {
                while ((currentLine=dbBufferReader.readLine()) != null) {
                    if (currentLine.startsWith(REPORT)) {
                        reportVersionLine=new ArrayList<>();
                        count=count + 1;
                    } else if (reportVersionLine != null) {
                        if (count == 2 || count == 3 || count == 6) {
                            reportVersionLine.add(currentLine);
                        }
                        count=count + 1;
                        if (reportVersionLine.size() == 3) {
                            DbBean dbBean=buildDbInfoBean(reportVersionLine);
                            if (isCreateFile) {
                                printWriter.append((recordCount + 1) + "," + (sdf.format(dbBean.getReportDate())) + "," + dbBean.getReportId() + "," + dbBean.getVersionNo() + "\n");
                                printWriter.flush();
                            } else {
                                dbBeanList.add(dbBean);
                            }
                            recordCount++;
                            reportVersionLine=null;
                            count=0;
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        if (isCreateFile) {
            printWriter.flush();
            printWriter.close();
        }
        System.out.println("Total Number of Records :" + recordCount);
        System.out.println("Total DBList Bean Size :" + dbBeanList.size());
        System.out.println("Total DBList Bean  :" + dbBeanList);
        return dbBeanList;
    }

    /**
     * Build Db List Bean
     *
     * @param dbReportVersionLine
     * @return dbBean
     */
    private DbBean buildDbInfoBean(List<String> dbReportVersionLine) {
        String line1=dbReportVersionLine.get(0);
        String line2=dbReportVersionLine.get(1);
        String line3=dbReportVersionLine.get(2);
        DbBean dbBean=DbBean.builder()
                /**
                 * Line 1
                 */.reportDate(buildReportDate(checkEmptyString(line1.substring(13 , 25)))).
                        reportId(checkEmptyString(line1.substring(1 , 12)))
                .versionNo(buildVersionNumber(checkEmptyString(line1.substring(13 , 35))))
                .pages(Long.parseLong(checkEmptyString(line1.substring(36 , 42).trim())))
                .status(checkEmptyString(line1.substring(45 , 53)))
                .datasetName(checkEmptyString(line1.substring(54 , 101)))
                .micrSubscript(checkEmptyString(line1.substring(99 , 115)))
                .dataType(checkEmptyString(line1.substring(117 , 127)))
                /**
                 * Line 2
                 */.comment(checkEmptyString(line2.substring(21 , 52))).recallExpDate(checkEmptyString(line2.substring(70 , 81))).recordStatusDate(checkEmptyString(line2.substring(100 , 111)))
                /**
                 * Line 3
                 */.unit(checkEmptyString(line3.substring(7 , 17))).volumnSer(checkEmptyString(line3.substring(18 , 27))).expirationDate(checkEmptyString(line3.substring(28 , 40))).seqNo(checkEmptyString(line3.substring(41 , 50))).migrationDatasetName(checkEmptyString(line3.substring(51 , 70))).numberOfBytes(checkEmptyString(line3.substring(98 , 115))).shareFlag(checkEmptyString(line3.substring(116 , 128))).build();
        return dbBean;
    }

    /**
     * Build Report Date
     *
     * @param existedReportDate
     * @return
     */
    private static Date buildReportDate(String existedReportDate) {
        SimpleDateFormat formatter=new SimpleDateFormat("MM/dd/yyyy");
        Date reportDate=null;
        try {
            reportDate=formatter.parse(existedReportDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return reportDate;
    }

    /**
     * Build Version Number
     *
     * @param existedVersionNumber
     * @return
     */
    private static String buildVersionNumber(String existedVersionNumber) {
        return existedVersionNumber.replace("/" , "").replace("  " , "").replace(":" , "").replace("." , "");
    }

    /**
     * Check Empty String
     *
     * @param value
     * @return
     */
    private static String checkEmptyString(String value) {
        value=value.trim();
        return value;
    }

    public String buildArchivalvalues(List<DbBean> dbBeanList) {
        List<String> archivalValuesList=new ArrayList<>();
        for (DbBean dbBean : dbBeanList) {
            archivalValuesList.add("[" + dbBean.getReportId() + "|" + dbBean.getVersionNo() + "]");
        }
        return String.join("," , archivalValuesList);
    }
}
