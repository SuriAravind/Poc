package processor;

import bean.MobiusInputBean;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPCmd;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static constants.MobiusConstants.LOGFILE;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 2:22 PM.
 */
public class SharedProcessor {
    protected MobiusInputBean mobiusInputBean;
    public SharedProcessor(MobiusInputBean mobiusInputBean) {
        this.mobiusInputBean=mobiusInputBean;
    }

    /**
     * Upload File
     *
     * @param localFilePath
     * @param ftpClient
     * @throws Exception
     */
    void uploadFile(String localFilePath , FTPClient ftpClient,String process) throws Exception {
        System.out.println(" Started to upload the "+process+" at " + mobiusInputBean.getRemoteTargetDirectory() + File.separator + mobiusInputBean.getRemoteFileName());
        try (InputStream input=new FileInputStream(localFilePath)) {
            ftpClient.storeFile(mobiusInputBean.getRemoteTargetDirectory() + mobiusInputBean.getRemoteFileName() , input);
        }
        System.out.println("Successfully Uploaded");
        System.out.println(ftpClient.getReplyString());
    }
    /**
     * Fetch Job Log Folder Name
     * @return
     * @throws IOException
     */
    String fetchJobLogFolderName() throws IOException {
        String storageLocation=mobiusInputBean.getSaveLocation();
        String jobLogFolderName="";
        File file=new File(storageLocation + File.separator + LOGFILE);
        List<String> logList=Files.readAllLines(Path.of(file.getAbsolutePath()));
        for (String log : logList) {
            CharSequence charSequence= "JES";
            if (log.startsWith("250") && log.contains("JES")) {
                jobLogFolderName=log.substring(log.indexOf("JES as") + 6);
            }
        }
        return jobLogFolderName;
    }

    /**
     * Retrive Job Log Folder
     *
     * @param ftpClient
     * @param jobLogFolderName
     * @return
     * @throws IOException
     */
    String retrieveJobLogFolder(FTPClient ftpClient , String jobLogFolderName) throws IOException {
        String storageLocation=mobiusInputBean.getSaveLocation();
        System.out.println("Start Retrieving the job log folder :" + jobLogFolderName);
        ftpClient.sendCommand(FTPCmd.RETR , jobLogFolderName);
        String logFileFromMainFrameFilePath=storageLocation + File.separator + jobLogFolderName + ".txt";
        OutputStream outputStream=new FileOutputStream(logFileFromMainFrameFilePath);
        ftpClient.retrieveFile(jobLogFolderName , outputStream);
        System.out.println("Successfully retrieved folder " + jobLogFolderName);
        return logFileFromMainFrameFilePath;
    }

    /**
     * Fetch Job Status
     *
     * @param logFileFromMainFrameFilePath
     * @return
     * @throws IOException
     */
    boolean fetchJobStatus(String logFileFromMainFrameFilePath) throws IOException {
        List<String> mainFrameLogFileLines=Files.readAllLines(Path.of(logFileFromMainFrameFilePath));
        String deleteJobRcString=mainFrameLogFileLines.get(10).substring(51 , 53);
        boolean deleteJob=deleteJobRcString.equalsIgnoreCase("00");
        String printArchJobRcString=mainFrameLogFileLines.get(11).substring(51 , 53);
        boolean printArchJob=printArchJobRcString.equalsIgnoreCase("00");
        return deleteJob && printArchJob;
    }

    /**
     * Retreive Final Output File
     *
     * @param finalFileName
     * @param storageLocation
     * @param ftpClient
     * @throws IOException
     */
    String retrieveFinalOutputFile(String finalFileName , String storageLocation , FTPClient ftpClient) throws IOException {
        ftpClient.sendCommand("SITE" , "FILETYPE=SEQ");
        String finalOutputFilePath=storageLocation + File.separator + finalFileName.replace("\\." , "_") + ".txt";
        OutputStream finalOutputFileStream=new FileOutputStream(finalOutputFilePath);
        ftpClient.retrieveFile("\'" + finalFileName + "\'" , finalOutputFileStream);
        return finalOutputFilePath;
    }
}
