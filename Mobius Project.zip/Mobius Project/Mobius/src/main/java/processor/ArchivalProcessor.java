package processor;

import bean.MobiusInputBean;
import bean.ReportVersionBean;
import core.CoreLogicBuilder;
import extraction.ExtractionFlow;
import org.apache.commons.net.ftp.FTPClient;
import utils.UtilityHelper;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import static constants.MobiusConstants.*;
import static utils.UtilityHelper.addEmptySpaceCharacter;
import static utils.UtilityHelper.readFilesAsString;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 1:02 PM.
 */
public class ArchivalProcessor extends SharedProcessor {
    private FTPClient ftpClient;
    /**
     * @param mobiusInputBean
     */
    public ArchivalProcessor(MobiusInputBean mobiusInputBean , FTPClient ftpClient) {
        super(mobiusInputBean);
        this.ftpClient=ftpClient;
    }
    /**
     * Start Archival Process
     *
     * @throws Exception
     */
    public void startArchivalProcess() throws Exception {
        String localFilePath=createJobFileForArchival();
        uploadFile(localFilePath , ftpClient , "final file");
        String jobLogFolderName=fetchJobLogFolderName();
        String logFileFromMainFrameFilePath=retrieveJobLogFolder(ftpClient , jobLogFolderName);
        System.out.println("Successfully retrieved folder " + jobLogFolderName);
        boolean jobStatus=fetchJobStatus(logFileFromMainFrameFilePath);
        System.out.println("Job Status " + jobStatus);
        if (jobStatus) {
            String finalOutputFilePath=retrieveFinalOutputFile(mobiusInputBean.getFinalFileName() , mobiusInputBean.getSaveLocation() , ftpClient);
            String outputLocation=new ExtractionFlow(mobiusInputBean.getOutputType() , mobiusInputBean.getSaveLocation() , mobiusInputBean.getArchivalValues() , mobiusInputBean.getIsReportVersionOnly() , finalOutputFilePath).startExtraction();
            System.out.println(" Output Files generated at " + outputLocation);
        } else {
            System.err.println("Delete Job Status | Print ArchJob Failed");
        }
    }
    /**
     * Create Job File For Archival
     *
     * @return
     * @throws Exception
     */
    private String createJobFileForArchival() throws Exception {
        String modifiedTemplatePrefixString=readFilesAsString("/template/Template_Prefix.txt").replace(TAG + "USER" + TAG , mobiusInputBean.getUser()).replace(TAG + "ROLL_NO" + TAG , mobiusInputBean.getRollNo()).replace(TAG + "CLASS" + TAG , mobiusInputBean.getClassName()).replace(TAG + "MSGCLASS" + TAG , mobiusInputBean.getMsgClassName()).replace(TAG + "DISK_PREFIX" + TAG , mobiusInputBean.getDiskPrefix()).replace(TAG + "VSAM_DATASET_PREFIX" + TAG , mobiusInputBean.getVsamDatasetPrefix()).replace(TAG + "LE_RUNTIME_DATASET" + TAG , mobiusInputBean.getLeRuntimeDataset()).replace(TAG + "FINAL_FILE_NAME" + TAG , mobiusInputBean.getFinalFileName());
        List<String> printCardList=fetchPrintCardList(mobiusInputBean.getUserID() , mobiusInputBean.getArchivalValues() , mobiusInputBean.getIsReportVersionOnly());
        String modifiedTemplateSuffixString=readFilesAsString("/template/Template_Suffix.txt").replace(TAG + "FINAL_FILE_NAME" + TAG , mobiusInputBean.getFinalFileName()).replace(TAG + "UNIT" + TAG , mobiusInputBean.getUnit()).replace(TAG + "SPACE" + TAG , mobiusInputBean.getSpace());
        String localFilePath=prepareJobFilePath(mobiusInputBean.getSaveLocation() , modifiedTemplatePrefixString , printCardList , modifiedTemplateSuffixString);
        System.out.println(" Final File Created at this path :" + localFilePath);
        return localFilePath;
    }
    /**
     * Fetch Print Card List
     *
     * @param userId
     * @param archivalValues
     * @return
     * @since
     */
    private List<String> fetchPrintCardList(String userId , String archivalValues , boolean isReportVersionOnly) throws Exception {
        List<String> printCardList=new ArrayList<>();
        List<ReportVersionBean> reportVersionList=new CoreLogicBuilder().buildReportVersionBean(archivalValues , isReportVersionOnly);
        for (ReportVersionBean reportVersion : reportVersionList) {
            StringBuffer printCard=new StringBuffer();
            printCard.append("##PRINT" + addEmptySpaceCharacter(7) + "01 " + UtilityHelper.addSpaceCharacter(userId , 10) + EMPTY_SPACE + UtilityHelper.addSpaceCharacter(reportVersion.getReportId() , 10) + EMPTY_SPACE + UtilityHelper.addSpaceCharacter(reportVersion.getVersionNo() , 14) + addEmptySpaceCharacter(20) + NL);
            printCard.append(addEmptySpaceCharacter(14) + "02 " + addEmptySpaceCharacter(7) + UtilityHelper.addSpaceCharacter(reportVersion.getSessionId() , 30) + EMPTY_SPACE + "N" + addEmptySpaceCharacter(20) + NL);
            printCard.append(addEmptySpaceCharacter(14) + "03 " + addEmptySpaceCharacter(50) + "@LAST" + NL);
            printCardList.add(printCard.toString());
        }
        return printCardList;
    }
    /**
     * Prepare Job File Path
     *
     * @param storageLocation
     * @param modifiedTemplatePrefixString
     * @param printCardList
     * @param modifiedTemplateSuffixString
     * @return
     * @throws IOException
     */
    private String prepareJobFilePath(String storageLocation , String modifiedTemplatePrefixString , List<String> printCardList , String modifiedTemplateSuffixString) throws IOException {
        StringBuffer jobFileStringBuffer=new StringBuffer();
        jobFileStringBuffer.append(modifiedTemplatePrefixString);
        jobFileStringBuffer.append("\n");
        jobFileStringBuffer.append(String.join("" , printCardList));
        jobFileStringBuffer.append(modifiedTemplateSuffixString);

        File jobLocalFile=new File(storageLocation + File.separator + "JobFile.txt");
        if (!jobLocalFile.exists()) {
            jobLocalFile.createNewFile();
        }
        PrintWriter printWriter=new PrintWriter(jobLocalFile.getAbsolutePath());
        printWriter.append(jobFileStringBuffer.toString());
        printWriter.flush();
        printWriter.close();
        String localFilePath=jobLocalFile.getAbsolutePath();
        return localFilePath;
    }

}
