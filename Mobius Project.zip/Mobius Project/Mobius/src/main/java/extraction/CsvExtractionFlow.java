package extraction;

import bean.AttachmentInfo;
import bean.ReportVersionBean;
import utils.UtilityHelper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import static constants.MobiusConstants.NL;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 12:33 PM.
 */
public class CsvExtractionFlow {
    /**
     * CSV Output Generation
     *
     * @param storageLocation
     * @param attachmentInfoMap
     * @param reportVersion
     * @param headers
     * @throws FileNotFoundException
     */
    public String csvOutputGeneration(String storageLocation , Map<String, AttachmentInfo> attachmentInfoMap , List<ReportVersionBean> reportVersion , List<String> headers , boolean isReportVersionOnly) throws Exception {
        File outputFolder=new File(storageLocation+File.separator+"OUTPUT");
        if (!outputFolder.exists()) {
            outputFolder.mkdir();
        }
        PrintWriter csvOutputWriter=new PrintWriter(outputFolder.getAbsolutePath() + File.separator + UtilityHelper.getSchemaTable() + "-00000.csv");
        csvOutputWriter.append(String.join("," , headers) + NL);
        int count=0;
        for (Map.Entry<String, AttachmentInfo> attachment : attachmentInfoMap.entrySet()) {
            if (isReportVersionOnly) {
                csvOutputWriter.append("\"" + attachment.getKey() + "\",\"" + reportVersion.get(count).getReportId() + "\",\"" + reportVersion.get(count).getVersionNo() + "\",\"" + attachment.getValue().getAttachmentDate() + "\",\"" + attachment.getValue().getAttachmentPath() + "\"" + NL);
            } else {
                csvOutputWriter.append("\"" + attachment.getKey() + "\",\"" + reportVersion.get(count).getReportId() + "\",\"" + reportVersion.get(count).getVersionNo() + "\",\"" + reportVersion.get(count).getSessionId() + "\",\"" + attachment.getValue().getAttachmentDate() + "\",\"" + attachment.getValue().getAttachmentPath() + "\"" + NL);
            }
        }
        csvOutputWriter.flush();
        csvOutputWriter.close();
        return  outputFolder.getAbsolutePath();
    }
}
