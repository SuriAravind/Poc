package extraction;

import bean.AttachmentInfo;
import bean.ReportVersionBean;
import utils.UtilityHelper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static constants.MobiusConstants.NL;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 12:15 PM.
 */
public class XmlExtractionFlow {
    /**
     * XMl Output Generation
     *
     * @param storageLocation
     * @param attachmentInfoMap
     * @param reportVersionList
     * @param headers
     * @throws IOException
     */
    public String xmlOutputGenerationWithMetadata(String storageLocation , Map<String, AttachmentInfo> attachmentInfoMap , List<ReportVersionBean> reportVersionList , List<String> headers , boolean isReportVersionOnly) throws Exception {
        File outputFolder=new File(storageLocation + File.separator + "OUTPUT");
        if (!outputFolder.exists()) {
            outputFolder.mkdir();
        }
        xmlExtractedDataGeneration(outputFolder.getAbsolutePath() , attachmentInfoMap , reportVersionList , isReportVersionOnly);
        xmlMetadataGeneration(outputFolder.getAbsolutePath() , reportVersionList.size() , headers);
        return outputFolder.getAbsolutePath();
    }

    /**
     * Xml Metadata Generation
     *
     * @param storageLocation
     * @param recordCount
     * @param headers
     * @throws FileNotFoundException
     */
    private void xmlMetadataGeneration(String storageLocation , long recordCount , List<String> headers) throws FileNotFoundException {
        PrintWriter xmlMetadataOutputWriter=new PrintWriter(storageLocation + File.separator + "Metadata_MOBIUS_DBO.xml");
        xmlMetadataOutputWriter.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + NL);
        xmlMetadataOutputWriter.append("<metadata>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(1) + "<caseSensitive>false</caseSensitive>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(1) + "<defaultSchema>MOBIUS_DBO</defaultSchema>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(1) + "<validatingOnIngest>false</validatingOnIngest>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(1) + "<locale>en-US</locale>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(1) + "<schemaMetadataList>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(2) + "<schemaMetadata>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(3) + "<name>MOBIUS_DBO</name>" + NL);
        // xmlMetadataOutputWriter.append(UtilityHelper.getSpace(3) + "<archonFormattedName>MOBIUS_DBO</archonFormattedName>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(3) + "<tableCount>1</tableCount>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(3) + "<tableMetadataList>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(4) + "<tableMetadata>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(5) + "<name>MOBIUS_TABLE</name>" + NL);
        // xmlMetadataOutputWriter.append(UtilityHelper.getSpace(5) + "<archonFormattedName>MOBIUS_TABLE</archonFormattedName>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(5) + "<recordCount>" + recordCount + "</recordCount>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(5) + "<columnList>" + NL);
        int oridinal=1;
        for (String column : headers) {
            xmlMetadataOutputWriter.append(UtilityHelper.getSpace(6) + "<column>" + NL);
            xmlMetadataOutputWriter.append(UtilityHelper.getSpace(7) + "<name>" + column + "</name>" + NL);
            // xmlMetadataOutputWriter.append(UtilityHelper.getSpace(7) + "<archonFormattedName>" + column + "</archonFormattedName>" + NL);
            xmlMetadataOutputWriter.append(UtilityHelper.getSpace(7) + "<ordinal>" + oridinal + "</ordinal>" + NL);
            xmlMetadataOutputWriter.append(UtilityHelper.getSpace(7) + "<type>" + ((column.equalsIgnoreCase("REPORT_DATE")) ? "DATE" : "VARCHAR") + "</type>" + NL);
            xmlMetadataOutputWriter.append(UtilityHelper.getSpace(7) + "<typeLength>" + ((column.equalsIgnoreCase("REPORT_DATE")) ? "19" : "255") + "</typeLength>" + NL);
            xmlMetadataOutputWriter.append(UtilityHelper.getSpace(7) + "<index>" + ((oridinal == 1) ? true : false) + "</index>" + NL);
            xmlMetadataOutputWriter.append(UtilityHelper.getSpace(6) + "</column>" + NL);
            oridinal++;
        }
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(5) + "</columnList>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(4) + "</tableMetadata>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(3) + "</tableMetadataList>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(2) + "</schemaMetadata>" + NL);
        xmlMetadataOutputWriter.append(UtilityHelper.getSpace(1) + "</schemaMetadataList>" + NL);
        xmlMetadataOutputWriter.append("</metadata>" + NL);
        xmlMetadataOutputWriter.flush();
        xmlMetadataOutputWriter.close();
    }

    /**
     * XML Extracted Data Generation
     *
     * @param storageLocation
     * @param attachmentInfoMap
     * @param reportVersionList
     * @throws IOException
     */
    private void xmlExtractedDataGeneration(String storageLocation , Map<String, AttachmentInfo> attachmentInfoMap , List<ReportVersionBean> reportVersionList , boolean isReportVersionOnly) throws Exception {
        PrintWriter xmlOutputWriter=new PrintWriter(storageLocation + File.separator + UtilityHelper.getSchemaTable() + "-00000.xml");
        xmlOutputWriter.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + NL);
        xmlOutputWriter.append("<MOBIUS_DBO>" + NL);
        xmlOutputWriter.append(UtilityHelper.getSpace(1) + "<MOBIUS_TABLE>" + NL);
        int count=0;
        for (Map.Entry<String, AttachmentInfo> attachment : attachmentInfoMap.entrySet()) {
            long size=Files.size(Path.of(attachment.getValue().getFullPath())) / 1024;
            xmlOutputWriter.append(UtilityHelper.getSpace(2) + "<ROW>" + NL);
            xmlOutputWriter.append(UtilityHelper.getSpace(3) + "<ID>" + attachment.getKey() + "</ID>" + NL);
            xmlOutputWriter.append(UtilityHelper.getSpace(3) + "<REPORT_ID>" + reportVersionList.get(count).getReportId() + "</REPORT_ID>" + NL);
            xmlOutputWriter.append(UtilityHelper.getSpace(3) + "<VERSION_NO>" + reportVersionList.get(count).getVersionNo() + "</VERSION_NO>" + NL);
            if (!isReportVersionOnly) {
                xmlOutputWriter.append(UtilityHelper.getSpace(3) + "<SECTION_ID>" + reportVersionList.get(count).getSessionId() + "</SECTION_ID>" + NL);
            }
            xmlOutputWriter.append(UtilityHelper.getSpace(3) + "<REPORT_DATE>" + attachment.getValue().getAttachmentDate() + "</REPORT_DATE>" + NL);
            xmlOutputWriter.append(UtilityHelper.getSpace(3) + "<ATTACHMENT type=\"BLOB\" ref=\"" + attachment.getValue().getAttachmentPath() + "\" size=\"" + size + "KB\" status=\"Success\">" + attachment.getKey() + "</ATTACHMENT>" + NL);
            xmlOutputWriter.append(UtilityHelper.getSpace(2) + "</ROW>" + NL);
            count++;
        }
        xmlOutputWriter.append("\t</MOBIUS_TABLE>" + NL);
        xmlOutputWriter.append("</MOBIUS_DBO>");
        xmlOutputWriter.flush();
        xmlOutputWriter.close();
    }

}
