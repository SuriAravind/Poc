package extraction;

import bean.AttachmentInfo;
import bean.OutputType;
import bean.ReportVersionBean;
import core.CoreLogicBuilder;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 12:21 PM.
 */
public class ExtractionFlow {

    private OutputType outputType;
    private String storageLocation;
    private List<ReportVersionBean> archivalValuesList;
    private boolean isReportVersionOnly;
    private Map<String, AttachmentInfo> attachmentInfoMap;
    private List<String> headerList;

    /**
     * Build Inputs for all the extraction flow
     *
     * @param outputType
     * @param storageLocation
     * @param archivalValues
     * @param isReportVersionOnly
     * @param finalFilePath
     * @throws Exception
     */
    public ExtractionFlow(OutputType outputType , String storageLocation , String archivalValues , boolean isReportVersionOnly , String finalFilePath) throws Exception {
        this.outputType=outputType;
        this.storageLocation=storageLocation;
        this.isReportVersionOnly=isReportVersionOnly;
        if (isReportVersionOnly) {
            headerList=Arrays.asList(new String[]{"ID" , "REPORT_ID" , "VERSION_NO" , "REPORT_DATE" , "ATTACHMENT"});
        } else {
            headerList=Arrays.asList(new String[]{"ID" , "REPORT_ID" , "VERSION_NO" , "SECTION_ID" , "REPORT_DATE" , "ATTACHMENT"});
        }
        CoreLogicBuilder coreLogicBuilder=new CoreLogicBuilder();
        this.archivalValuesList=coreLogicBuilder.buildReportVersionBean(archivalValues , isReportVersionOnly);
        this.attachmentInfoMap=coreLogicBuilder.buildAttachmentFileCreationIntoBlobFolder(finalFilePath , storageLocation);
    }

    /**
     * Start Extraction
     *
     * @throws Exception
     */
    public String startExtraction() throws Exception {
        switch (outputType) {
            case CSV:
               return new CsvExtractionFlow().csvOutputGeneration(storageLocation , attachmentInfoMap , archivalValuesList , headerList , isReportVersionOnly);
            case XML:
            default:
                return new XmlExtractionFlow().xmlOutputGenerationWithMetadata(storageLocation , attachmentInfoMap , archivalValuesList , headerList , isReportVersionOnly);
         }
    }
}
