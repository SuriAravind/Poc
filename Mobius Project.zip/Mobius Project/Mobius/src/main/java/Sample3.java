import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Suriyanarayanan K ❣❣❣
 * on 23/04/21 11:51 AM.
 */
public class Sample3 {
    public static void main(String[] args) throws ParseException {
        System.out.println(buildExtractionVersionCreationDate("06232015220458"));
        //System.out.println(buildVersionTimeforPreAnlaysis("20150623220303"));
        System.out.println(buildVersionDateforPreAnlaysis("20150623"));
        System.out.println("Time :"+new Date().getTime());
        System.out.println(new Date(1420050600));
        System.out.println(new Date(1620239399));
        System.out.println(new Date(1434997800));
    }
    public static String buildExtractionVersionCreationDate(String versionName) throws ParseException {
        String refactorVersionNo=versionName.substring(4 , 8) + versionName.substring(0 , 2) + versionName.substring(2 , 4) + versionName.substring(8);
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyyMMddhhmmss");
        Date date=simpleDateFormat.parse(refactorVersionNo);
        System.out.println(date.toString());
        System.out.println(date.getTime());
        SimpleDateFormat simpleDateFormat2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        return simpleDateFormat2.format(date);
    }
    public static Long buildVersionTimeforPreAnlaysis(String versionName) throws ParseException {
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyyMMddhhmmss");
        Date date=simpleDateFormat.parse(versionName);
        System.out.println(date);
        System.out.println(date.getTime());
        Date newDate=new Date(date.getTime());
        System.out.println(newDate);
        return date.getTime()/1000;
    }
    public static Long buildVersionDateforPreAnlaysis(String versionName) throws ParseException {
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyyMMdd");
        Date date=simpleDateFormat.parse(versionName);
        return date.getTime();
    }
}
