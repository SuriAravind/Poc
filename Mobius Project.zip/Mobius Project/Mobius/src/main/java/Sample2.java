import bean.MobiusReportVersionBean;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Suriyanarayanan K ❣❣❣
 * on 22/04/21 11:57 AM.
 */
public class Sample2 {
    public static String REPORT="-REPORT";
    public static void main(String[] args) throws FileNotFoundException {
        List<MobiusReportVersionBean> mobiusReportVersionBeanList=new ArrayList<>();
        String dbListOutputPath="/Users/apple/Documents/Mobius Project/Input/DBList_Output.txt";
        File file=new File(dbListOutputPath);
        try (BufferedReader dbBufferReader=new BufferedReader(new FileReader(file) , 4096)) {
            String currentLine="";
            int count=0;
            long dbListFileCount=0;
            MobiusReportVersionBean currentMobiusReportVersionBean=null;
            String currentVersionName=null;
            long temporaryReportStartNumber=0;
            if(dbBufferReader.ready()){
                while ((currentLine=dbBufferReader.readLine()) != null) {
                    if (currentLine.startsWith(REPORT)) {
                        count=0;
                        temporaryReportStartNumber=dbListFileCount;
                        if(currentMobiusReportVersionBean==null){
                            currentMobiusReportVersionBean=MobiusReportVersionBean.builder()
                                    .startLineNumber(temporaryReportStartNumber).build();
                        }
                        count=count+1;
                    }
                    else if(count==2){
                        String reportName=checkEmptyString(currentLine.substring(1 , 12));
                        if(currentVersionName ==null){
                            currentVersionName=reportName;
                        }
                        if(!currentVersionName.equalsIgnoreCase(reportName)){
                            currentMobiusReportVersionBean.setEndLineNumber(dbListFileCount-2);
                            mobiusReportVersionBeanList.add(currentMobiusReportVersionBean);
                            currentMobiusReportVersionBean=MobiusReportVersionBean.builder()
                                    .startLineNumber(temporaryReportStartNumber).build();
                        }
                        count=count+1;
                    }else if(currentMobiusReportVersionBean!=null){
                        count=count+1;
                    }
                    dbListFileCount=dbListFileCount+1;
                }
            }
            currentMobiusReportVersionBean.setEndLineNumber(dbListFileCount);
            mobiusReportVersionBeanList.add(currentMobiusReportVersionBean);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(" Mobius Version List :"+mobiusReportVersionBeanList);
        for(MobiusReportVersionBean mobius:mobiusReportVersionBeanList){
            System.out.println("Start Line :"+mobius.getStartLineNumber());
            System.out.println("End Line :"+mobius.getEndLineNumber());
        }
    }
    /**
     * Check Empty String
     *
     * @param value
     * @return
     */
    public static  String checkEmptyString(String value) {
        value=value.trim();
        return value;
    }
}
