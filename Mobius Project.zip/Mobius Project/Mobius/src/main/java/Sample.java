import java.io.*;

/**
 * Created by Suriyanarayanan K ❣❣❣
 * on 21/04/21 4:44 PM.
 */
public class Sample {
    public static void main(String[] args) throws IOException {
        PrintWriter printWriter=new PrintWriter("/Users/apple/Documents/Mobius Project/ReportTestInputFile.csv");
        printWriter.append("Sno,ReportId,VersionNo");
        String finalFilePath ="/Users/apple/Documents/Mobius Project/SHDDP004.txt";
        File file=new File(finalFilePath);
        FileReader fr=new FileReader(file);
        BufferedReader br=new BufferedReader(fr , 4096);
        String line;
        String reportValue="";
        String versionValue="";
        int count=0;
        while ((line=br.readLine()) != null) {
            line=line.substring(1);
            if(line.contains("**            REPORT ID:")){
                reportValue=line.substring(line.indexOf(":")+1,line.indexOf("PAYROLL ADVICE REGISTER")).trim();
            }if(line.contains("**              VERSION:")){
                count=count +1;
                versionValue=line.substring(line.indexOf(":")+2).replace(" ","").replace("**","").trim();
                printWriter.append("\n"+count+","+reportValue+","+versionValue);
            }
        }
        printWriter.flush();
        printWriter.close();
    }
}
