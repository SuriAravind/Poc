package core;

import bean.AttachmentInfo;
import bean.ReportVersionBean;
import utils.UtilityHelper;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 12:37 PM.
 */
public class CoreLogicBuilder {
    /**
     * Build Attachment File Creation Into Blob Folder
     *
     * @param finalFilePath
     * @param storageLocation
     * @throws IOException
     */
    public Map<String, AttachmentInfo> buildAttachmentFileCreationIntoBlobFolder(String finalFilePath , String storageLocation) throws IOException {
        Map<String, AttachmentInfo> attachmentInfoMap=new LinkedHashMap<>();

        String blobFolderPath=storageLocation + File.separator + "BLOBs";
        File blobFolder=new File(blobFolderPath);
        blobFolder.mkdir();

        String attachmentFolderPath=blobFolderPath + File.separator + UtilityHelper.getSchemaTable();
        File attachmentFolder=new File(attachmentFolderPath);
        attachmentFolder.mkdir();

        File file=new File(finalFilePath);
        FileReader fr=new FileReader(file);
        BufferedReader br=new BufferedReader(fr , 4096);
        String line;
        PrintWriter printWriter=null;
        int viewDirectCount=0;
        while ((line=br.readLine()) != null) {
            if (line.contains("************************************************* ViewDirect *************************************************")) {
                if (viewDirectCount == 0) {
                    if (printWriter != null) {
                        printWriter.flush();
                        printWriter.close();
                        printWriter=null;
                    }
                    viewDirectCount=viewDirectCount + 1;
                    String fileName=UUID.randomUUID().toString() + ".txt";
                    String attachmentPath=File.separator + "BLOBs" + File.separator + UtilityHelper.getSchemaTable() + File.separator + fileName;
                    long millis=System.currentTimeMillis();
                    java.sql.Date date=new java.sql.Date(millis);
                    attachmentInfoMap.put(fileName , AttachmentInfo.builder().attachmentPath(attachmentPath).fullPath(storageLocation + attachmentPath).attachmentDate(date.toString()).build());
                    printWriter=new PrintWriter(storageLocation + attachmentPath);
                    printWriter.append(UtilityHelper.formattedReportValueString(line));
                } else if (viewDirectCount == 1) {
                    printWriter.append("\n");
                    printWriter.append(UtilityHelper.formattedReportValueString(line));
                    viewDirectCount=0;
                }
            } else if (printWriter != null) {
                printWriter.append("\n");
                printWriter.append(UtilityHelper.formattedReportValueString(line));
            }
        }
        if (printWriter != null) {
            printWriter.flush();
            printWriter.close();
        }
        fr.close();

        return attachmentInfoMap;
    }

    /**
     * Build Report Version Bean
     *
     * @return
     * @throws Exception
     */
    public static List<ReportVersionBean> buildReportVersionBean(String archivalValues , boolean isReportVersionOnly) throws Exception {
        List<ReportVersionBean> reportVersionBeanList=new ArrayList<>();
        List<String> reportVersionSessionList=Arrays.asList(archivalValues.split(",")).stream().map(line -> line.replace("[" , "").replace("]" , "")).collect(Collectors.toList());
        for (String reportVersionSession : reportVersionSessionList) {
            String[] str=reportVersionSession.split("\\|");
            if(isReportVersionOnly){
                if (str.length == 2) {
                    reportVersionBeanList.add(ReportVersionBean.builder().reportId(str[0]).versionNo(str[1]).build());
                } else {
                    throw new Exception("Invalid Report Version Value :" + reportVersionSession);
                }
            }else{
                if (str.length == 3) {
                    reportVersionBeanList.add(ReportVersionBean.builder().reportId(str[0]).versionNo(str[1]).sessionId(str[2]).build());
                } else {
                    throw new Exception("Invalid Report Version Value :" + reportVersionSession);
                }
            }
        }
        return reportVersionBeanList;
    }

}
