package utils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 11:42 AM.
 */
public class UtilityHelper {
    /**
     * Add Space Character
     *
     * @param value
     * @param totalLength
     * @return
     */
    public static String addSpaceCharacter(String value , int totalLength) {
        if(value==null){
            value=new String();
        }
        int remainingLength=totalLength-value.length();
        if (value.length() < totalLength) {
            for (int i=0; i < remainingLength; i++) {
                value=value + " ";
            }
        }
        return value;
    }
    /**
     * Get Space
     *
     * @param spaceCount
     * @return
     */
    public static String getSpace(int spaceCount) {
        String str="";
        for (int i=0; i < spaceCount; i++) {
            str+="\t";
        }
        return str;
    }
    /**
     * Schema table name
     *
     * @return
     */
    public static String getSchemaTable() {
        return "MOBIUS_DBO-MOBIUS_TABLE";
    }
    /**
     * Formatted Report Value String
     *
     * @param line
     * @return
     */
    public static String formattedReportValueString(String line) {
        return line.replace("¤" , "").replace("\u0019" , "").replace("�" , "").substring(1);
    }
    /**
     * Read Files As String
     *
     * @param templatePath
     * @return
     * @throws Exception
     */
    public static String readFilesAsString(String templatePath) throws Exception {
        InputStream prefixStream=UtilityHelper.class.getResourceAsStream(templatePath);
        if (prefixStream == null) throw new Exception("Resource not found: " + templatePath);
        return new BufferedReader(new InputStreamReader(prefixStream , StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
    }
    /**
     * Add Empty Space Character
     *
     * @param totalLength
     * @return
     */
    public static String addEmptySpaceCharacter(int totalLength) {
        String value="";
        for (int i=0; i < totalLength; i++) {
            value=value + " ";
        }
        return value;
    }
}
