package creator;

import bean.MobiusInputBean;
import bean.OutputType;
import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import utils.PropertyFileReader;
import utils.UtilityHelper;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import static constants.MobiusConstants.LOGFILE;

/**
 * Created by Suriyanarayanan K
 * on 30/03/21 11:39 AM.
 */
public class ConfigToBeanCreator {


    /**
     * Build FTP Client
     *
     * @param host
     * @param userName
     * @param password
     * @param storageLocation
     * @return FTPClient
     * @throws Exception
     */
    public FTPClient buildFTPClient(String host , String userName , String password , String storageLocation) {
        FTPClient ftp=new FTPClient();
        try {
            ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(storageLocation + File.separator + LOGFILE)));
            int reply;
            ftp.connect(host);
            reply=ftp.getReplyCode();
            if (!FTPReply.isPositiveCompletion(reply)) {
                ftp.disconnect();
                throw new Exception("Exception in connecting to FTP Server");
            }
            ftp.login(userName , password);
            ftp.setFileType(FTP.ASCII_FILE_TYPE);
            ftp.sendCommand("SITE" , "FILETYPE=JES");
            System.out.println(" SITE Command executed");
            ftp.enterLocalPassiveMode();
            System.out.println(" Passive Command executed");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return ftp;
    }
    /**
     * Prepare Mobius Input Bean
     *
     * @return MobiusInputBean
     */
    public MobiusInputBean prepareMobiusInputBean() {
        PropertyFileReader propertyFileReader=new PropertyFileReader("config.properties");
        /**
         * Connection Parameters
         * */
        String hostName=propertyFileReader.getStringValue("HOST" , "");
        String userName=propertyFileReader.getStringValue("USER" , "");
        String password=propertyFileReader.getStringValue("PASSWORD" , "");
        String remoteFileName=propertyFileReader.getStringValue("REMOTE_FILE_NAME" , "");
        String remoteTargetDirectory=propertyFileReader.getStringValue("REMOTE_TARGET_DIRECTORY" , "");

        /**
         * Single Time Configuration
         * */
        String rollNo=propertyFileReader.getStringValue("ROLL_NO" , "");
        String className=propertyFileReader.getStringValue("CLASS" , "");
        String messageClassName=propertyFileReader.getStringValue("MSGCLASS" , "");
        String diskPrefixName=propertyFileReader.getStringValue("DISK_PREFIX" , "");
        String vsamDatasetPrefixName=propertyFileReader.getStringValue("VSAM_DATASET_PREFIX" , "");
        String leRuntimeDatasetName=propertyFileReader.getStringValue("LE_RUNTIME_DATASET" , "");
        String finalFileName=propertyFileReader.getStringValue("FINAL_FILE_NAME" , "");
        String unitName=propertyFileReader.getStringValue("UNIT" , "");
        String spaceName=propertyFileReader.getStringValue("SPACE" , "");

        /**
         * Run Time Configuration
         * */
        String userId=UtilityHelper.addSpaceCharacter(propertyFileReader.getStringValue("USER_ID" , "") , 10);
        boolean isReportVersionOnly=propertyFileReader.getBooleanValue("IS_REPORT_VERSION_ONLY" , false);
        String archivalValues="";
        if (isReportVersionOnly) {
            archivalValues=propertyFileReader.getStringValue("REPORT_VERSION" , "");
        } else {
            archivalValues=propertyFileReader.getStringValue("REPORT_VERSION_SECTION" , "");
        }

        /**
         * Output Location
         */
        String storageLocation=propertyFileReader.getStringValue("SAVE_LOCATION" , "");
        OutputType outputType=OutputType.valueOf(propertyFileReader.getStringValue("OUTPUT_TYPE" , "XML"));

        /**
         * Process
         */
        boolean isRetreivalDBList=propertyFileReader.getBooleanValue("IS_RETRIEVAL_DB_LIST" , false);
        boolean isArchivalReport=propertyFileReader.getBooleanValue("IS_ARCHIVAL_REPORT" , false);

        boolean isDbListReportFileCreator=propertyFileReader.getBooleanValue("IS_CREATE_REPORT_CSV_FILE" , false);
        String localDbListFilePath=propertyFileReader.getStringValue("LOCAL_DBLIST_FILE_PATH" , "");
        return MobiusInputBean.builder().archivalValues(archivalValues).className(className).diskPrefix(diskPrefixName).finalFileName(finalFileName).host(hostName).isReportVersionOnly(isReportVersionOnly).isRetrievalDblist(isRetreivalDBList).isArchivalReport(isArchivalReport).leRuntimeDataset(leRuntimeDatasetName).msgClassName(messageClassName).outputType(outputType).password(password).remoteFileName(remoteFileName).remoteTargetDirectory(remoteTargetDirectory).rollNo(rollNo).saveLocation(storageLocation).space(spaceName).unit(unitName).user(userName).userID(userId).vsamDatasetPrefix(vsamDatasetPrefixName).isDbListReportFileCreator(isDbListReportFileCreator).localDbListFilePath(localDbListFilePath).build();
    }

    /**
     * Disconnect FTP
     *
     * @throws Exception
     */
    public void disconnect(FTPClient ftpClient) throws Exception {
        if (ftpClient.isConnected()) {
            try {
                ftpClient.logout();
                ftpClient.disconnect();
            } catch (IOException f) {
                System.err.println(f.getMessage());
                throw new Exception(f);
            }
        }
    }
}
