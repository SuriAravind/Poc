import bean.DbBean;
import bean.MobiusInputBean;
import creator.ConfigToBeanCreator;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.ftp.FTPClient;
import processor.ArchivalProcessor;
import processor.DbListProcessor;

import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Objects;

/**
 * Created by Suriyanarayanan K
 * on 16/03/21 1:34 PM.
 */
public class MobiusMain {
    /**
     * Mobius Main Function
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {

        System.out.println("Start");
        ConfigToBeanCreator configToBeanCreator=new ConfigToBeanCreator();
        MobiusInputBean mobiusInputBean=configToBeanCreator.prepareMobiusInputBean();


        if (mobiusInputBean.getIsDbListReportFileCreator()) {
            DbListProcessor dbListProcessor=new DbListProcessor();
            List<DbBean> dbBeanList=dbListProcessor.retrieveAllDBList(mobiusInputBean.getLocalDbListFilePath(),true);
        } else {
            FTPClient ftpClient=configToBeanCreator.buildFTPClient(mobiusInputBean.getHost() , mobiusInputBean.getUser() , mobiusInputBean.getPassword() , mobiusInputBean.getSaveLocation());
            if (mobiusInputBean.getIsRetrievalDblist() && mobiusInputBean.getIsArchivalReport()) {
                DbListProcessor dbListProcessor=new DbListProcessor(mobiusInputBean , ftpClient);
                String archivedDBListOutputPath=dbListProcessor.retrieveDBListFromMainFrameDBIntoLocal();
                if (Objects.isNull(archivedDBListOutputPath)) {
                    System.err.println("Unable to fetch db list file");
                } else {
                    List<DbBean> dbBeanList=dbListProcessor.retrieveAllDBList(archivedDBListOutputPath,false);
                    String archivalValues=dbListProcessor.buildArchivalvalues(dbBeanList);
                    mobiusInputBean.setArchivalValues(archivalValues);
                    mobiusInputBean.setIsReportVersionOnly(true);

                    ftpClient.sendCommand("SITE" , "FILETYPE=JES");
                    System.out.println(" SITE Command executed");
                    ArchivalProcessor archivalProcessor=new ArchivalProcessor(mobiusInputBean , ftpClient);
                    archivalProcessor.startArchivalProcess();
                }
            } else if (mobiusInputBean.getIsRetrievalDblist()) {

                DbListProcessor dbListProcessor=new DbListProcessor(mobiusInputBean , ftpClient);
                String archivedDBListOutputPath=dbListProcessor.retrieveDBListFromMainFrameDBIntoLocal();
                if (!StringUtils.isEmpty(archivedDBListOutputPath)) {
                    List<DbBean> dbBeanList=dbListProcessor.retrieveAllDBList(archivedDBListOutputPath,false);
                    System.out.println(" DBLIST SIZE :" + dbBeanList.size());
                    System.out.println("DBLIS :" + dbBeanList);
                }

            } else if (mobiusInputBean.getIsArchivalReport()) {

                ArchivalProcessor archivalProcessor=new ArchivalProcessor(mobiusInputBean , ftpClient);
                archivalProcessor.startArchivalProcess();

            } else {
                System.err.println(" your are not given any operation to work");
            }
            configToBeanCreator.disconnect(ftpClient);
        }

        System.out.println("Done");
    }
}
