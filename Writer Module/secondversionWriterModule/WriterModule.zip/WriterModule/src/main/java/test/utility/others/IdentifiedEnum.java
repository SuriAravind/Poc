package test.utility.others;

public interface IdentifiedEnum {
    
    int getId();
    
}
