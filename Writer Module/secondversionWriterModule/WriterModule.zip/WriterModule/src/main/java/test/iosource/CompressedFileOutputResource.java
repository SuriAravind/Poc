/*
========================================================================
SchemaCrawler
http://www.schemacrawler.com
Copyright (c) 2000-2016, Sualeh Fatehi <sualeh@hotmail.com>.
All rights reserved.
------------------------------------------------------------------------

SchemaCrawler is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

SchemaCrawler and the accompanying materials are made available under
the terms of the Eclipse Public License v1.0, GNU General Public License
v3 or GNU Lesser General Public License v3.

You may elect to redistribute this code under any of these licenses.

The Eclipse Public License is available at:
http://www.eclipse.org/legal/epl-v10.html

The GNU General Public License v3 and the GNU Lesser General Public
License v3 are available at:
http://www.gnu.org/licenses/

========================================================================
*/
package test.iosource;


import test.utility.others.StringFormat;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static java.nio.file.Files.*;
import static java.nio.file.StandardOpenOption.*;
import static java.util.Objects.requireNonNull;

public class CompressedFileOutputResource
        implements OutputResource {
    
    private static final Logger LOGGER = Logger.getLogger(CompressedFileOutputResource.class.getName());
    
    private final Path outputFile;
    private final String internalPath;
    
    public CompressedFileOutputResource(final Path filePath, final String internalPath) throws IOException {
        outputFile = requireNonNull(filePath, "No file path provided").normalize().toAbsolutePath();
        final Path parentPath = requireNonNull(filePath.getParent(), "Invalid output directory");
        if (!exists(parentPath) || !isWritable(parentPath) || !isDirectory(parentPath)) {
            throw new IOException("Cannot write file, " + filePath);
        }
        
        this.internalPath = requireNonNull(internalPath, "No internal file path provided");
    }
    
    public Path getOutputFile() {
        return outputFile;
    }
    
    @Override
    public Writer openNewOutputWriter(final Charset charset, final boolean appendOutput) throws IOException {
        if (appendOutput) {
            throw new IOException("Cannot append to compressed file");
        }
        final OpenOption[] openOptions = new OpenOption[]{WRITE, CREATE, TRUNCATE_EXISTING};
        final OutputStream fileStream = newOutputStream(outputFile, openOptions);
        
        final ZipOutputStream zipOutputStream = new ZipOutputStream(fileStream);
        zipOutputStream.putNextEntry(new ZipEntry(internalPath));
        
        final Writer writer = new OutputStreamWriter(zipOutputStream, charset);
        LOGGER.log(Level.INFO, new StringFormat("Opened output writer to compressed file, %s", outputFile));
        return new OutputWriter(getDescription(), writer, true);
    }
    
    private String getDescription() {
        return outputFile.toString();
    }
    
    @Override
    public String toString() {
        return getDescription();
    }
    
}
