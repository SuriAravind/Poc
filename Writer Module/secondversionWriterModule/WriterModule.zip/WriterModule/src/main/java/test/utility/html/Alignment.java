package test.utility.html;


public enum Alignment {
    inherit,
    left,
    right;
}
